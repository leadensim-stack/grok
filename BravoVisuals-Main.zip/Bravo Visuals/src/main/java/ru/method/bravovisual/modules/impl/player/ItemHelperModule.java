package ru.method.bravovisual.modules.impl.player;

import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;

public class ItemHelperModule
extends Module {
    public ItemHelperModule() {
        super("ItemHelper", ModuleCategory.Player);
    }
}

