package ru.method.bravovisual.api.mixins;

import net.minecraft.class_10042;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import ru.method.bravovisual.api.accessor.ItemEntityRenderStateAccessor;

@Mixin(value={class_10042.class})
public class LivingEntityRenderStateMixin
implements ItemEntityRenderStateAccessor {
    @Unique
    private boolean bravovisual$isPlayer;
    @Unique
    private float bravovisual$hitColorStrength;

    @Override
    public boolean bravovisual$isPlayer() {
        return this.bravovisual$isPlayer;
    }

    @Override
    public void bravovisual$setPlayer(boolean bl) {
        this.bravovisual$isPlayer = bl;
    }

    @Override
    public float bravovisual$getHitColorStrength() {
        return this.bravovisual$hitColorStrength;
    }

    @Override
    public void bravovisual$setHitColorStrength(float f) {
        this.bravovisual$hitColorStrength = f;
    }
}

