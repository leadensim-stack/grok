package ru.method.bravovisual.modules.impl.render;

import ru.method.bravovisual.api.setting.Setting;

import net.minecraft.class_1074;
import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;
import ru.method.bravovisual.api.setting.SliderSetting;

public class AspectRatioModule
extends Module {
    public final SliderSetting yP = new SliderSetting(class_1074.method_4662((String)"settings.aspectratio.ratio", (Object[])new Object[0]), 1.75f, 0.1f, 5.0f, 0.05f);

    public AspectRatioModule() {
        super("AspectRatio", ModuleCategory.Visuals);
    }
}

