package ru.method.bravovisual.modules.impl.player;

import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;

public class ScoreboardHealthModule
extends Module {
    public ScoreboardHealthModule() {
        super("ScoreboardHealth", ModuleCategory.Player);
    }
}

