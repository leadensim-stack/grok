package ru.method.bravovisual.api.mixins;

import net.minecraft.class_10039;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import ru.method.bravovisual.api.accessor.LivingEntityRenderStateAccessor;

@Mixin(value={class_10039.class})
public class ItemEntityRenderStateMixin
implements LivingEntityRenderStateAccessor {
    @Unique
    private boolean bravovisual$onGround;
    @Unique
    private float bravovisual$horizontalSpeed;
    @Unique
    private float bravovisual$verticalSpeed;
    @Unique
    private float bravovisual$xRotation;
    @Unique
    private float bravovisual$yRotation;
    @Unique
    private boolean bravovisual$additionalOffset;

    @Override
    public boolean bravovisual$isOnGround() {
        return this.bravovisual$onGround;
    }

    @Override
    public void bravovisual$setOnGround(boolean bl) {
        this.bravovisual$onGround = bl;
    }

    @Override
    public float bravovisual$getHorizontalSpeed() {
        return this.bravovisual$horizontalSpeed;
    }

    @Override
    public void bravovisual$setHorizontalSpeed(float f) {
        this.bravovisual$horizontalSpeed = f;
    }

    @Override
    public float bravovisual$getVerticalSpeed() {
        return this.bravovisual$verticalSpeed;
    }

    @Override
    public void bravovisual$setVerticalSpeed(float f) {
        this.bravovisual$verticalSpeed = f;
    }

    @Override
    public float bravovisual$getXRotation() {
        return this.bravovisual$xRotation;
    }

    @Override
    public void bravovisual$setXRotation(float f) {
        this.bravovisual$xRotation = f;
    }

    @Override
    public float bravovisual$getYRotation() {
        return this.bravovisual$yRotation;
    }

    @Override
    public void bravovisual$setYRotation(float f) {
        this.bravovisual$yRotation = f;
    }

    @Override
    public boolean bravovisual$hasAdditionalOffset() {
        return this.bravovisual$additionalOffset;
    }

    @Override
    public void bravovisual$setAdditionalOffset(boolean bl) {
        this.bravovisual$additionalOffset = bl;
    }
}

