package ru.method.bravovisual.modules.impl.client;

import net.minecraft.class_2960;
import ru.method.bravovisual.BravoVisual;
import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;

public class AllSkinsModule
extends Module {
    public static final class_2960 yO = BravoVisual.id("textures/allskins/rudi.png");

    public AllSkinsModule() {
        super("AllSkins", ModuleCategory.Other);
    }

    public static class_2960 it() {
        BravoVisual bravoVisual = BravoVisual.getInstance();
        if (bravoVisual == null || bravoVisual.getModuleManager() == null) {
            return null;
        }
        AllSkinsModule allSkinsModule = bravoVisual.getModuleManager().getModule(AllSkinsModule.class);
        return allSkinsModule != null && allSkinsModule.isToggle() ? yO : null;
    }
}

