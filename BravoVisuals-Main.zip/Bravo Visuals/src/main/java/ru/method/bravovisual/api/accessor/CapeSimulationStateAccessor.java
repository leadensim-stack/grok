package ru.method.bravovisual.api.accessor;

import ru.method.bravovisual.modules.impl.render.cosmetic.CapeSimulation;

public interface CapeSimulationStateAccessor {
    public CapeSimulation bravovisual$capeSimulation();

    public void bravovisual$setCapeSimulation(CapeSimulation var1);

    public float bravovisual$capeTickDelta();

    public void bravovisual$setCapeTickDelta(float var1);

    public boolean bravovisual$capeCrouching();

    public void bravovisual$setCapeCrouching(boolean var1);
}

