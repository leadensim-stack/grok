package ru.method.bravovisual.api.accessor;

public interface LivingEntityRenderStateAccessor {
    public boolean bravovisual$isOnGround();

    public void bravovisual$setOnGround(boolean var1);

    public float bravovisual$getHorizontalSpeed();

    public void bravovisual$setHorizontalSpeed(float var1);

    public float bravovisual$getVerticalSpeed();

    public void bravovisual$setVerticalSpeed(float var1);

    public float bravovisual$getXRotation();

    public void bravovisual$setXRotation(float var1);

    public float bravovisual$getYRotation();

    public void bravovisual$setYRotation(float var1);

    public boolean bravovisual$hasAdditionalOffset();

    public void bravovisual$setAdditionalOffset(boolean var1);
}

