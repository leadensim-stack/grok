package ru.method.bravovisual.module;

import lombok.Generated;

public enum ModuleCategory {
    Combat("P"),
    Movement("S"),
    Visuals("R"),
    Player("V"),
    Other("V"),
    qo("H");
    private final String qp;

@Generated
    private ModuleCategory(String string2) {
        this.qp = string2;
    }

    @Generated
    public String fK() {
        return this.qp;
    }

}

