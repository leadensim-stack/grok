package ru.method.bravovisual.modules.impl.render.cosmetic;

public enum CosmeticSlot {
    dr,
    ds,
    dt,
    du;
}

