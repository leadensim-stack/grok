package ru.method.bravovisual.api.setting;

import java.util.function.Supplier;
import ru.method.bravovisual.input.KeyBind;
import ru.method.bravovisual.api.setting.Setting;

public class BindSetting
extends Setting<KeyBind> {
    public BindSetting(String string, KeyBind keyBind) {
        super(string, keyBind);
    }

    public BindSetting(String string, KeyBind keyBind, Supplier<Boolean> supplier) {
        super(string, keyBind, supplier);
    }
}

