package ru.method.bravovisual.modules.impl.render.cosmetic;

public enum CosmeticEffectType {
    dj,
    dk,
    dl,
    dm;
}

