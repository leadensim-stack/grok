package ru.method.bravovisual.modules.impl.render;

import ru.method.bravovisual.api.setting.ColorSetting;
import ru.method.bravovisual.api.setting.EnumSetting;
import ru.method.bravovisual.api.setting.NamedOption;
import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;

import java.awt.Color;

public class SkyChangerModule
extends Module {
    private final EnumSetting<SkyMode> mode = new EnumSetting<SkyMode>("modules.settings.skychanger.mode", SkyMode.STATIC);
    private final ColorSetting skyColor = new ColorSetting("modules.settings.skychanger.color", new Color(120, 60, 200, 180));
    private final ColorSetting horizonColor = new ColorSetting("modules.settings.skychanger.horizon", new Color(60, 30, 120, 180));

    public SkyChangerModule() {
        super("SkyChanger", ModuleCategory.Visuals);
        this.getSettings().add(this.mode);
        this.getSettings().add(this.skyColor);
        this.getSettings().add(this.horizonColor);
    }

    public int ae(int originalColor) {
        Color targetColor = getTargetColor();
        float f = (float) targetColor.getAlpha() / 255.0f;
        int n2 = originalColor >> 16 & 0xFF;
        int n3 = originalColor >> 8 & 0xFF;
        int n4 = originalColor & 0xFF;
        int n5 = clamp(Math.round((float)n2 * (1.0f - f) + (float)targetColor.getRed() * f));
        int n6 = clamp(Math.round((float)n3 * (1.0f - f) + (float)targetColor.getGreen() * f));
        int n7 = clamp(Math.round((float)n4 * (1.0f - f) + (float)targetColor.getBlue() * f));
        return n5 << 16 | n6 << 8 | n7;
    }

    private Color getTargetColor() {
        return switch (this.mode.jT()) {
            case MIDNIGHT -> new Color(15, 18, 35, 230);
            case SUNSET -> new Color(245, 110, 60, 210);
            case CYBERPUNK -> new Color(0, 215, 255, 200);
            case NEON_PURPLE -> new Color(175, 45, 245, 200);
            default -> (Color) this.skyColor.jT();
        };
    }

    private static int clamp(int n) {
        return Math.max(0, Math.min(255, n));
    }

    public enum SkyMode implements NamedOption {
        STATIC("Custom"),
        MIDNIGHT("Midnight"),
        SUNSET("Sunset"),
        CYBERPUNK("Cyberpunk"),
        NEON_PURPLE("Neon Purple");

        private final String name;

        SkyMode(String name) {
            this.name = name;
        }

        @Override
        public String getName() {
            return this.name;
        }
    }
}
