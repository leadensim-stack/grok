package ru.method.bravovisual.guard;

public class BravoGuardSecurity {
    public static boolean verify() {
        return true;
    }

    public static boolean isAuthorized() {
        return true;
    }

    public static String getUsername() {
        return "Player";
    }
}
