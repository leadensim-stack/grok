package ru.method.bravovisual.api.accessor;

import ru.method.bravovisual.modules.impl.render.cosmetic.CapeSimulation;

public interface CapeSimulationAccessor {
    public CapeSimulation bravovisual$capeSimulation();
}

