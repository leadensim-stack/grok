package ru.method.bravovisual.api.accessor;

public interface ItemEntityRenderStateAccessor {
    public boolean bravovisual$isPlayer();

    public void bravovisual$setPlayer(boolean var1);

    public float bravovisual$getHitColorStrength();

    public void bravovisual$setHitColorStrength(float var1);
}

