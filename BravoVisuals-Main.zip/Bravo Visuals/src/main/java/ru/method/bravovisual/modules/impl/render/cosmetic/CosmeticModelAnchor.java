package ru.method.bravovisual.modules.impl.render.cosmetic;

public enum CosmeticModelAnchor {
    cY,
    cZ;
}

