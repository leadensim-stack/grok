package ru.method.bravovisual.api.setting;

public interface NamedOption {
    public String getName();
}

