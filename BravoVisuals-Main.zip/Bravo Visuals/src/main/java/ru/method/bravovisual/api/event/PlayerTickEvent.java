package ru.method.bravovisual.api.event;

import ru.method.bravovisual.api.event.CancellableEvent;

public class PlayerTickEvent
extends CancellableEvent {
}

