package ru.method.bravovisual.punchy.client.render;

public interface MinecartLightState {
    public void punchy$setLight(int var1);

    public int punchy$getLight();
}

