package ru.method.bravovisual.media;

import ru.method.bravovisual.media.MediaSessionTracker;

public final class MediaSessionRegistry {
    private static final MediaSessionTracker lX = new MediaSessionTracker();

    private MediaSessionRegistry() {
    }

    public static MediaSessionTracker dy() {
        return lX;
    }
}

