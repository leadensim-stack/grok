package ru.method.bravovisual.input;

import lombok.Generated;
import ru.method.bravovisual.ui.NotificationIcon;

public final class KeyConstants {
    public static NotificationIcon akO = new NotificationIcon("K");
    public static NotificationIcon akP = new NotificationIcon("L");
    public static NotificationIcon akQ = new NotificationIcon("Q");

    @Generated
    private KeyConstants() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

