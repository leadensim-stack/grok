package ru.method.bravovisual.punchy.client.modelparts;

import ru.method.bravovisual.animation.Animation;

import net.minecraft.class_310;
import ru.method.bravovisual.punchy.client.animation.ItemAnimationManager;

final class AnimationStateMachine {
    AnimationStateMachine() {
    }

    void tick(class_310 class_3102) {
        ItemAnimationManager.tick(class_3102);
    }
}

