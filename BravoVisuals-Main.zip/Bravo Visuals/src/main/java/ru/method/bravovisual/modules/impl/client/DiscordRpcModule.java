package ru.method.bravovisual.modules.impl.client;

import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;
import ru.method.bravovisual.utils.client.discord.DiscordManager;

public class DiscordRpcModule
        extends Module {
    public DiscordRpcModule() {
        super("DiscordRPC", ModuleCategory.Other);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        DiscordManager.startRPC();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        DiscordManager.stopRPC();
    }
}

