package ru.method.bravovisual.api.event;

import lombok.Generated;
import ru.method.bravovisual.api.event.CancellableEvent;
import ru.method.bravovisual.api.setting.Setting;

public class SettingChangedEvent
extends CancellableEvent {
    private final Setting<?> ab;

    @Generated
    public SettingChangedEvent(Setting<?> setting) {
        this.ab = setting;
    }

    @Generated
    public Setting<?> o() {
        return this.ab;
    }
}

