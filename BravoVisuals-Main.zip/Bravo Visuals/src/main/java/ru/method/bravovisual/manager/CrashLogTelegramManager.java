package ru.method.bravovisual.manager;

public class CrashLogTelegramManager {
    public boolean isEnabled() {
        return false;
    }

    public String em() {
        return "";
    }

    public String en() {
        return "";
    }

    public void a(boolean bl, String string, String string2) {
    }

    public void shutdown() {
    }

    public void eh() {
    }
}
