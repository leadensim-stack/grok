package ru.method.bravovisual.managers.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.Generated;import meteordevelopment.orbit.EventHandler;
import ru.method.bravovisual.BravoVisual;
import ru.method.bravovisual.api.events.impl.EventMouse;
import ru.method.bravovisual.modules.impl.client.*;
import ru.method.bravovisual.modules.impl.render.AspectRatioModule;
import ru.method.bravovisual.modules.impl.player.AutoAcceptModule;
import ru.method.bravovisual.modules.impl.player.AutoNearModule;
import ru.method.bravovisual.modules.impl.player.AutoRelistModule;
import ru.method.bravovisual.modules.impl.player.AutoReplyModule;
import ru.method.bravovisual.modules.impl.player.AutoSpecModule;
import ru.method.bravovisual.modules.impl.combat.AutoSwapModule;
import ru.method.bravovisual.modules.impl.render.BlockOverlayModule;
import ru.method.bravovisual.modules.impl.player.ChatHelperModule;
import ru.method.bravovisual.modules.impl.render.ChinaHatModule;
import ru.method.bravovisual.input.ClickGuiKeyHandler;
import ru.method.bravovisual.modules.impl.movement.ClickGuiWalkModule;
import ru.method.bravovisual.modules.impl.player.ClickPearlModule;
import ru.method.bravovisual.modules.impl.player.CommandDelayModule;
import ru.method.bravovisual.modules.impl.player.CoordInviteModule;
import ru.method.bravovisual.modules.impl.player.CosmeticsModule;
import ru.method.bravovisual.modules.impl.player.CrasherModule;
import ru.method.bravovisual.modules.impl.render.CrosshairModule;
import ru.method.bravovisual.modules.impl.render.CustomHitBoxModule;
import ru.method.bravovisual.modules.impl.render.CustomVitalsModule;
import ru.method.bravovisual.modules.impl.render.DamageParticlesModule;
import ru.method.bravovisual.modules.impl.player.DeathCoordsModule;
import ru.method.bravovisual.modules.impl.render.DrochkaModule;
import ru.method.bravovisual.modules.impl.player.ElytraSwapModule;
import ru.method.bravovisual.modules.impl.player.FakePlayerModule;
import ru.method.bravovisual.modules.impl.player.FastExpModule;
import ru.method.bravovisual.modules.impl.render.FogBlurModule;
import ru.method.bravovisual.modules.impl.render.FortniteDamageModule;
import ru.method.bravovisual.modules.impl.render.FreeLookModule;
import ru.method.bravovisual.modules.impl.combat.FriendHelperModule;
import ru.method.bravovisual.modules.impl.render.FullbrightModule;
import ru.method.bravovisual.modules.impl.player.FunTimeHelperModule;
import ru.method.bravovisual.modules.impl.render.HandsModule;
import ru.method.bravovisual.modules.impl.render.HitColorModule;
import ru.method.bravovisual.modules.impl.render.HitRangeModule;
import ru.method.bravovisual.modules.impl.player.HitSoundModule;
import ru.method.bravovisual.modules.impl.player.HolyWorldHelperModule;
import ru.method.bravovisual.modules.impl.player.ItemHelperModule;
import ru.method.bravovisual.modules.impl.render.ItemPhysicsModule;
import ru.method.bravovisual.modules.impl.player.ItemPickupModule;
import ru.method.bravovisual.modules.impl.render.ItemRadiusModule;
import ru.method.bravovisual.modules.impl.player.ItemScrollerModule;
import ru.method.bravovisual.modules.impl.render.JumpCirclesModule;
import ru.method.bravovisual.input.KeyBind;
import ru.method.bravovisual.api.event.KeyInputEvent;
import ru.method.bravovisual.modules.impl.render.KillEffectModule;
import ru.method.bravovisual.modules.impl.render.KillStreakModule;
import ru.method.bravovisual.modules.impl.player.LockSlotModule;
import ru.method.bravovisual.modules.impl.player.LowArmorNotifyModule;
import ru.method.bravovisual.modules.impl.player.MineHelperModule;
import ru.method.bravovisual.api.accessor.MinecraftClientAccess;
import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;
import ru.method.bravovisual.modules.impl.render.MotionBlurModule;
import ru.method.bravovisual.api.event.MouseScrollEvent;
import ru.method.bravovisual.modules.impl.movement.MovementHelperModule;
import ru.method.bravovisual.modules.impl.render.NoRenderModule;
import ru.method.bravovisual.modules.impl.render.ParticlesModule;
import ru.method.bravovisual.modules.impl.player.PlayerUtilsModule;
import ru.method.bravovisual.modules.impl.player.PotionTrackerModule;
import ru.method.bravovisual.modules.impl.player.PvpSaveModule;
import ru.method.bravovisual.modules.impl.player.ReallyWorldHelperModule;
import ru.method.bravovisual.modules.impl.player.ScoreboardHealthModule;
import ru.method.bravovisual.modules.impl.render.SelfNametagsModule;
import ru.method.bravovisual.api.setting.SettingPersistence;
import ru.method.bravovisual.modules.impl.combat.ShiftTapModule;
import ru.method.bravovisual.modules.impl.player.ShulkerTooltipModule;
import ru.method.bravovisual.modules.impl.render.SkyChangerModule;
import ru.method.bravovisual.modules.impl.player.SoundsModule;
import ru.method.bravovisual.modules.impl.movement.SprintModule;
import ru.method.bravovisual.modules.impl.render.SwingAnimationModule;
import ru.method.bravovisual.modules.impl.player.TapeMouseModule;
import ru.method.bravovisual.modules.impl.render.TargetEspModule;
import ru.method.bravovisual.modules.impl.player.TotemCounterModule;
import ru.method.bravovisual.modules.impl.player.TotemTrackerModule;
import ru.method.bravovisual.modules.impl.render.TrailsModule;
import ru.method.bravovisual.modules.impl.render.TrajectoriesModule;
import ru.method.bravovisual.modules.impl.player.UseTrackerModule;
import ru.method.bravovisual.modules.impl.render.ViewModelModule;
import ru.method.bravovisual.modules.impl.player.WaypointsModule;
import ru.method.bravovisual.modules.impl.render.WorldModule;
import ru.method.bravovisual.modules.impl.render.ZoomModule;
import ru.method.bravovisual.modules.impl.client.DiscordRpcModule;

public class ModuleManager
implements MinecraftClientAccess {
    private final List<Module> modules = new ArrayList<Module>();
    private final Map<Class<? extends Module>, Module> moduleLookup = new HashMap<Class<? extends Module>, Module>();
    private final Map<ModuleCategory, List<Module>> modulesByCategory = new LinkedHashMap<ModuleCategory, List<Module>>();
    private final List<ModuleCategory> categories = List.of(ModuleCategory.values());

    public ModuleManager() {
        BravoVisual.getInstance().getEventHandler().subscribe((Object)this);
        for (ModuleCategory moduleCategory : ModuleCategory.values()) {
            this.modulesByCategory.put(moduleCategory, new ArrayList());
        }
        this.addModules(new SprintModule(), new TrajectoriesModule(), new ChinaHatModule(), new MovementHelperModule(), new UI(), new NoRenderModule(), new ItemScrollerModule(), new TargetEspModule(), new AllSkinsModule(), new HitRangeModule(), new SelfNametagsModule(), new AutoSwapModule(),  new DiscordRpcModule(), new ShiftTapModule(), new AspectRatioModule(), new CustomHitBoxModule(), new BlockOverlayModule(), new HandsModule(), new ItemHelperModule(), new ElytraSwapModule(), new DamageParticlesModule(), new ParticlesModule(), new FogBlurModule(), new MotionBlurModule(), new TrailsModule(), new WorldModule(), new SwingAnimationModule(), new FullbrightModule(), new ZoomModule(), new FreeLookModule(), new JumpCirclesModule(), new ItemPhysicsModule(), new FunTimeHelperModule(), new FriendHelperModule(), new ReallyWorldHelperModule(), new AutoNearModule(), new AutoRelistModule(), new AutoSpecModule(), new CoordInviteModule(), new DeathCoordsModule(), new ChatHelperModule(), new ClickPearlModule(), new CommandDelayModule(), new ItemPickupModule(), new LowArmorNotifyModule(), new LockSlotModule(), new MineHelperModule(), new PlayerUtilsModule(), new PvpSaveModule(), new TapeMouseModule(), new WaypointsModule(), new PartyModule(), new AutoAcceptModule(), new HolyWorldHelperModule(), new PotionTrackerModule(), new UseTrackerModule(), new HitSoundModule(), new SoundsModule(), new KillEffectModule(), new KillStreakModule(), new ViewModelModule(), new ScoreboardHealthModule(), new StreamerModeModule(), new ClickGuiWalkModule(), new TotemTrackerModule(), new TotemCounterModule(), new ShulkerTooltipModule(), new ItemRadiusModule(), new DrochkaModule(), new SkyChangerModule(), new HitColorModule(), new CrosshairModule(), new FortniteDamageModule(), new CustomVitalsModule(), new FastExpModule(), new AutoReplyModule(), new FakePlayerModule(), new SecretDupeModule(), new ElementsModule(), new CosmeticsModule(), new CrasherModule(), new ru.method.bravovisual.modules.impl.render.SuperResolutionModule());
        for (Module module : this.modules) {
            SettingPersistence.a(module, module.getSettings(), module.getName());
        }
    }

    private void addModules(Module ... moduleArray) {
        for (Module module : moduleArray) {
            this.modules.add(module);
            this.moduleLookup.put(module.getClass(), module);
            this.modulesByCategory.computeIfAbsent(module.getCategory(), moduleCategory -> new ArrayList()).add(module);
        }
    }

    @EventHandler
    public void onKey(KeyInputEvent keyInputEvent) {
        if (BravoVisual.getInstance().isPanic()) {
            return;
        }
        if (keyInputEvent.getAction() == 1) {
            Object object;
            int n = keyInputEvent.c();
            if (n < 0) {
                return;
            }
            UI uI = this.getModule(UI.class);
            if (uI != null && (object = uI.getBind()) != null && (ClickGuiKeyHandler.a(uI, n) || ((KeyBind)object).af(n))) {
                return;
            }
            if (Module.fullNullCheck() || ModuleManager.aiG.field_1755 != null) {
                return;
            }
            for (Module module : this.modules) {
                KeyBind keyBind;
                if (module instanceof UI || (keyBind = module.getBind()).isEmpty() || keyBind.jW() || keyBind.c() != n) continue;
                module.toggle();
            }
        }
    }

    @EventHandler
    public void onMouse(EventMouse eventMouse) {
        if (Module.fullNullCheck() || ModuleManager.aiG.field_1755 != null || BravoVisual.getInstance().isPanic()) {
            return;
        }
        if (eventMouse.getAction() == 1) {
            int n = eventMouse.getButton();
            if (n < 0) {
                return;
            }
            for (Module module : this.modules) {
                KeyBind keyBind = module.getBind();
                if (keyBind.isEmpty() || !keyBind.jW() || keyBind.c() != n) continue;
                module.toggle();
            }
        }
    }

    @EventHandler
    public void onScroll(MouseScrollEvent mouseScrollEvent) {
        if (Module.fullNullCheck() || ModuleManager.aiG.field_1755 != null || BravoVisual.getInstance().isPanic()) {
            return;
        }
        double d = mouseScrollEvent.h();
        if (d == 0.0) {
            return;
        }
        for (Module module : this.modules) {
            if (module instanceof UI || !module.getBind().c(d)) continue;
            module.toggle();
        }
    }

    public List<Module> getModules(ModuleCategory moduleCategory) {
        return this.modulesByCategory.getOrDefault((Object)moduleCategory, List.of());
    }

    public List<ModuleCategory> getCategories() {
        return this.categories;
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        return (T)this.moduleLookup.get(clazz);
    }

    @Generated
    public List<Module> getModules() {
        return this.modules;
    }

    @Generated
    public Map<Class<? extends Module>, Module> getModuleLookup() {
        return this.moduleLookup;
    }

    @Generated
    public Map<ModuleCategory, List<Module>> getModulesByCategory() {
        return this.modulesByCategory;
    }
}

