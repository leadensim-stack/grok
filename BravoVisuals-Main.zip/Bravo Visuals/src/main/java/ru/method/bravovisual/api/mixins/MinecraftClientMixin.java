package ru.method.bravovisual.api.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4071;
import net.minecraft.class_419;
import net.minecraft.class_425;
import net.minecraft.class_433;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_5250;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.method.bravovisual.BravoVisual;
import ru.method.bravovisual.api.mixins.DisconnectedScreenAccessor;
import ru.method.bravovisual.api.render.builders.renderers.impl.BuiltBlur;
import ru.method.bravovisual.api.event.ClientTickEvent;
import ru.method.bravovisual.render.ColorMath;
import ru.method.bravovisual.screen.DisconnectedScreen;
import ru.method.bravovisual.screen.MultiplayerScreen;
import ru.method.bravovisual.screen.PauseMenuScreen;
import ru.method.bravovisual.render.ServerEntryRenderer;
import ru.method.bravovisual.render.SettingsEntryRenderer;
import ru.method.bravovisual.util.Stopwatch;
import ru.method.bravovisual.utils.render.LiquidGlassReflectionCache;
import ru.method.bravovisual.utils.render.RenderFrameTracker;
import ru.method.bravovisual.utils.render.WorldSnapshotCache;

@Mixin(value={class_310.class})
public abstract class MinecraftClientMixin {
    @Inject(method={"render"}, at={@At(value="HEAD")})
    private void bravovisual$beginFrame(boolean bl, CallbackInfo callbackInfo) {
        RenderFrameTracker.beginFrame();
    }

    @Inject(method={"setScreen"}, at={@At(value="HEAD")})
    private void bravovisual$endJoinFlow(class_437 class_4372, CallbackInfo callbackInfo) {
        if (class_4372 == null || class_4372 instanceof class_442 || class_4372 instanceof class_419) {
            ServerEntryRenderer.pZ();
        }
    }

    @Inject(method={"setScreen"}, at={@At(value="HEAD")}, cancellable=true)
    private void bravovisual$redirectDisconnected(class_437 class_4372, CallbackInfo callbackInfo) {
        if (class_4372 instanceof class_419) {
            class_2561 class_25612;
            class_419 class_4192 = (class_419)class_4372;
            class_310 class_3102 = (class_310)(Object)this;
            try {
                class_25612 = ((DisconnectedScreenAccessor)class_4192).bravovisual$getInfo().comp_2853();
            }
            catch (Throwable throwable) {
                class_25612 = class_2561.method_43473();
            }
            boolean bl = class_3102.method_29043();
            class_642 class_6422 = class_3102.method_1558();
            callbackInfo.cancel();
            class_3102.method_1507((class_437)new DisconnectedScreen(class_4192.method_25440(), class_25612, bl, class_6422));
        }
    }

    @Inject(method={"setScreen"}, at={@At(value="HEAD")}, cancellable=true)
    private void bravovisual$redirectMultiplayer(class_437 class_4372, CallbackInfo callbackInfo) {
        if (class_4372 instanceof class_500) {
            callbackInfo.cancel();
            ((class_310)(Object)this).method_1507((class_437)new MultiplayerScreen(null));
        }
    }

    @Inject(method={"setScreen"}, at={@At(value="HEAD")}, cancellable=true)
    private void bravovisual$redirectPauseMenu(class_437 class_4372, CallbackInfo callbackInfo) {
        class_433 class_4332;
        if (class_4372 instanceof class_433 && (class_4332 = (class_433)class_4372).method_53558()) {
            callbackInfo.cancel();
            ((class_310)(Object)this).method_1507((class_437)new PauseMenuScreen());
        }
    }

    @Inject(method={"setScreen"}, at={@At(value="HEAD")}, cancellable=true)
    private void bravovisual$redirectOptions(class_437 class_4372, CallbackInfo callbackInfo) {
        class_437 class_4373 = SettingsEntryRenderer.e(class_4372);
        if (class_4373 == null) {
            return;
        }
        callbackInfo.cancel();
        ((class_310)(Object)this).method_1507(class_4373);
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    public void tick(CallbackInfo callbackInfo) {
        ClientTickEvent clientTickEvent = new ClientTickEvent();
        BravoVisual.getInstance().getEventHandler().post((Object)clientTickEvent);
        Stopwatch.rS();
    }

    @ModifyExpressionValue(method={"handleBlockBreaking"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z")})
    public boolean handleBlockBreaking(boolean bl) {
        return bl;
    }

    @ModifyExpressionValue(method={"doItemUse"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerInteractionManager;isBreakingBlock()Z")})
    public boolean doItemUse(boolean bl) {
        return bl;
    }

    @Inject(method={"setOverlay"}, at={@At(value="TAIL")})
    private void bravovisual$trackOverlay(class_4071 class_40712, CallbackInfo callbackInfo) {
        if (class_40712 instanceof class_425) {
            ColorMath.rx();
        }
    }

    @Inject(method={"close"}, at={@At(value="HEAD")})
    private void bravovisual$releaseRenderResources(CallbackInfo callbackInfo) {
        BravoVisual bravoVisual = BravoVisual.getInstance();
        if (bravoVisual != null && bravoVisual.getConfigManager() != null) {
            bravoVisual.getConfigManager().dV();
        }
        if (bravoVisual != null) {
            try {
                if (bravoVisual.getUsageStatsManager() != null) {
                    bravoVisual.getUsageStatsManager().shutdown();
                }
                if (bravoVisual.getUserSyncManager() != null) {
                    bravoVisual.getUserSyncManager().shutdown();
                }
                if (bravoVisual.getCrashLogTelegramManager() != null) {
                    bravoVisual.getCrashLogTelegramManager().shutdown();
                }
            }
            catch (Throwable throwable) {
            }
        }
        LiquidGlassReflectionCache.clear();
        BuiltBlur.releaseTempFramebuffer();
        WorldSnapshotCache.release();
    }
}
