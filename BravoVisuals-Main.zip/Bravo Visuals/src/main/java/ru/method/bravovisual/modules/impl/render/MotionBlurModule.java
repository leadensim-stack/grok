package ru.method.bravovisual.modules.impl.render;

import ru.method.bravovisual.api.setting.Setting;

import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;
import ru.method.bravovisual.api.setting.SliderSetting;
import ru.method.bravovisual.utils.render.MotionBlurRenderer;

public class MotionBlurModule
extends Module {
    private final SliderSetting EZ = new SliderSetting("settings.motionblur.strength", 50.0f, 5.0f, 90.0f, 5.0f);

    public MotionBlurModule() {
        super("MotionBlur", ModuleCategory.Visuals);
    }

    @Override
    public void onDisable() {
        MotionBlurRenderer.release();
        super.onDisable();
    }

    public void iH() {
        MotionBlurRenderer.render(((Float)this.EZ.jT()).floatValue() / 100.0f);
    }
}

