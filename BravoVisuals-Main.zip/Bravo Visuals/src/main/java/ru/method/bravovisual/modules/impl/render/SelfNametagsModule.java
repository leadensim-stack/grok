package ru.method.bravovisual.modules.impl.render;

import ru.method.bravovisual.module.Module;
import ru.method.bravovisual.module.ModuleCategory;

public class SelfNametagsModule
extends Module {
    public SelfNametagsModule() {
        super("SelfNametags", ModuleCategory.Visuals);
    }
}

