package ru.method.bravovisual.manager;

import ru.method.bravovisual.api.accessor.MinecraftClientAccess;

public class UsageStatsManager implements MinecraftClientAccess {
    public boolean isEnabled() {
        return false;
    }

    public String eB() {
        return "";
    }

    public void a(boolean bl, String string) {
    }

    public void shutdown() {
    }

    public void eC() {
    }
}
