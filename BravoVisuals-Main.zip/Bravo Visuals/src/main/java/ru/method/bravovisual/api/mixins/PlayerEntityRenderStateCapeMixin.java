package ru.method.bravovisual.api.mixins;

import net.minecraft.class_10055;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import ru.method.bravovisual.modules.impl.render.cosmetic.CapeSimulation;
import ru.method.bravovisual.api.accessor.CapeSimulationStateAccessor;

@Mixin(value={class_10055.class})
public class PlayerEntityRenderStateCapeMixin
implements CapeSimulationStateAccessor {
    @Unique
    private CapeSimulation bravovisual$capeSimulation;
    @Unique
    private float bravovisual$capeTickDelta;
    @Unique
    private boolean bravovisual$capeCrouching;

    @Override
    public CapeSimulation bravovisual$capeSimulation() {
        return this.bravovisual$capeSimulation;
    }

    @Override
    public void bravovisual$setCapeSimulation(CapeSimulation capeSimulation) {
        this.bravovisual$capeSimulation = capeSimulation;
    }

    @Override
    public float bravovisual$capeTickDelta() {
        return this.bravovisual$capeTickDelta;
    }

    @Override
    public void bravovisual$setCapeTickDelta(float f) {
        this.bravovisual$capeTickDelta = f;
    }

    @Override
    public boolean bravovisual$capeCrouching() {
        return this.bravovisual$capeCrouching;
    }

    @Override
    public void bravovisual$setCapeCrouching(boolean bl) {
        this.bravovisual$capeCrouching = bl;
    }
}

